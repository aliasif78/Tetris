/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */



//          Name : Ali Asif                     Roll No : 22i-1019



int BLOCKS[7][4] =
    {
        {1, 3, 5, 7}, // I
        {0, 1, 3, 5}, // J
        {3, 5, 7, 6}, // L
        {0, 1, 3, 2}, // O
        {1, 3, 2, 4}, // S
        {0, 2, 3, 5}, // Z
        {2, 1, 3, 5}  // T
};

